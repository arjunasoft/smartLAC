package controllers;

public class lampus extends CRUD {

}
