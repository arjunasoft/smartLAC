package controllers;

public class Gedungs extends CRUD {

}
