package controllers;

public class ruangans extends CRUD {

}
